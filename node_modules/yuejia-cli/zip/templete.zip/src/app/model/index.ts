class Model {

}

const model = new Model();

export default model;