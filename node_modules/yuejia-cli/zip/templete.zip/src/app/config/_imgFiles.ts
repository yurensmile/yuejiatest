// const example = require('路径/example.png');

// export default {
//   /** 列子 */
//   example,
// };