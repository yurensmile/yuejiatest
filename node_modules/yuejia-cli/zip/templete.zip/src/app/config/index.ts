// import imgFiles from './_imgFiles';
// import svgFiles from './_svgFiles';
import variable from './_variable';
// import style from './_style';

export default {
  // imgFiles,
  // svgFiles,
  variable,
  // style
};