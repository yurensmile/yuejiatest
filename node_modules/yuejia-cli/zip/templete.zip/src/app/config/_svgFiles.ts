// import svgRootPath from 'yuejia/utils/svgRootPath';

// const example = require('路径/example.svg');

// export default {
//   /** 列子 */
//   prompt: svgRootPath + example.id,
// };
