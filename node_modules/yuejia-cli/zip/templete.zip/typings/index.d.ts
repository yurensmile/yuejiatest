/// <reference path="../node_modules/yuejia/typings/module.d.ts" />
/// <reference path="./module.d.ts" />
